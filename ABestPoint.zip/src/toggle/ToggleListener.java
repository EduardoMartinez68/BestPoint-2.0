package toggle;

public interface ToggleListener {

    public void onSelected(boolean selected);

    public void onAnimated(float animated);
}
